<?php
/*
Plugin Name: Custom Login Message
Description: Display a custom message on the login page.
Version: 1.0
Author: Your Name
*/

// Hook to display the custom message on the login page
function clm_custom_login_message() {
    $message = get_option('clm_login_message', 'Welcome to our site! Please login to continue.');
    echo '<p style="color: #0073aa; font-size: 18px; text-align: center;">' . esc_html($message) . '</p>';
}
add_action('login_message', 'clm_custom_login_message');

// Add a settings page to customize the login message
function clm_add_settings_page() {
    add_options_page(
        'Custom Login Message Settings',
        'Login Message',
        'manage_options',
        'custom-login-message',
        'clm_settings_page_content'
    );
}
add_action('admin_menu', 'clm_add_settings_page');

// Display settings page content
function clm_settings_page_content() {
    ?>
    <div class="wrap">
        <h1>Custom Login Message Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('clm_options_group');
            do_settings_sections('custom-login-message');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Custom Login Message</th>
                    <td><input type="text" name="clm_login_message" value="<?php echo esc_attr(get_option('clm_login_message')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Register plugin settings
function clm_register_settings() {
    register_setting('clm_options_group', 'clm_login_message');
}
add_action('admin_init', 'clm_register_settings');
// Redirect user after login (optional)
function clm_redirect_after_login( $redirect_to, $request, $user ) {
    // Redirect to the home page after login
    return home_url();
}
add_filter( 'login_redirect', 'clm_redirect_after_login', 10, 3 );
