<?php
/*
Plugin Name: Random Quote Generator Widget
Plugin URI: http://localhost/wordpress
Description: A simple widget to display random quotes on your WordPress site.
Version: 1.0
Author: Your Name
Author URI: http://yourwebsite.com
License: GPL2
*/

// Prevent direct access to the file
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Register the widget
function register_random_quote_widget() {
    register_widget( 'Random_Quote_Generator_Widget' );
}
add_action( 'widgets_init', 'register_random_quote_widget' );

// Create the widget class
class Random_Quote_Generator_Widget extends WP_Widget {

    // Set up the widget
    function __construct() {
        parent::__construct(
            'random_quote_generator_widget', // Base ID
            'Random Quote Generator', // Widget name
            array( 'description' => 'Displays a random quote on your site.' ) // Widget description
        );
    }

    // Front-end display of the widget
    public function widget( $args, $instance ) {
        // Get the quotes from the options (you could store them in the database)
        $quotes = array(
            'The only limit to our realization of tomorrow is our doubts of today. – Franklin D. Roosevelt',
            'Do not go where the path may lead, go instead where there is no path and leave a trail. – Ralph Waldo Emerson',
            'The future belongs to those who believe in the beauty of their dreams. – Eleanor Roosevelt',
            'In the end, we will remember not the words of our enemies, but the silence of our friends. – Martin Luther King Jr.',
            'It always seems impossible until it’s done. – Nelson Mandela',
        );
    
        // Randomly select a quote
        $random_quote = $quotes[ array_rand( $quotes ) ];
    
        // Debugging: Check if the widget is displaying
        echo '<div style="background-color: #f0f0f0; padding: 10px; margin-bottom: 10px;">';
        echo '<p><strong>Widget Loaded!</strong></p>';
        echo $args['before_widget'];
        echo $args['before_title'] . 'Random Quote' . $args['after_title'];
        echo '<p>' . esc_html( $random_quote ) . '</p>';
        echo $args['after_widget'];
        echo '</div>';
    }
    

    // Back-end widget form (admin interface)
    public function form( $instance ) {
        // No configuration for now, so just leave this empty
        echo '<p>No configurable options available.</p>';
    }

    // Update widget settings
    public function update( $new_instance, $old_instance ) {
        // For now, nothing to update
        return $instance;
    }
}
// Enqueue the plugin's CSS file
function random_quote_widget_styles() {
    wp_enqueue_style( 'random-quote-widget', plugin_dir_url( __FILE__ ) . 'style.css' );
}
add_action( 'wp_enqueue_scripts', 'random_quote_widget_styles' );
