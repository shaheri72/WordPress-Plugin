<?php
/*
Plugin Name: Animated Scroll Effects
Description: Adds scroll-triggered animations to elements on your WordPress site.
Version: 1.0
Author: Your Name
*/

// Enqueue the necessary scripts and styles
function animated_scroll_effects_enqueue_scripts() {
    wp_enqueue_style('animate-css', 'https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css');
    wp_enqueue_script('scroll-trigger-js', 'https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js', array('jquery'), null, true);
    wp_enqueue_script('animated-scroll-effects-js', plugins_url('animated-scroll-effects.js', __FILE__), array('jquery', 'scroll-trigger-js'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'animated_scroll_effects_enqueue_scripts');

// Shortcode to apply animations
function animated_scroll_effects_shortcode($atts, $content = null) {
    $atts = shortcode_atts(array(
        'animation' => 'fadeIn',
        'delay' => '0s',
    ), $atts);

    return '<div class="animated-scroll-effect" data-animation="' . esc_attr($atts['animation']) . '" data-delay="' . esc_attr($atts['delay']) . '">' . do_shortcode($content) . '</div>';
}
add_shortcode('animate', 'animated_scroll_effects_shortcode');
