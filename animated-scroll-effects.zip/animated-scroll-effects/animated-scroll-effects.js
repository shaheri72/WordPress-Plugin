jQuery(document).ready(function ($) {
    $('.animated-scroll-effect').each(function () {
        var $this = $(this);
        var animation = $this.data('animation');
        var delay = $this.data('delay');

        $this.css({
            'opacity': 0,
            'animation-delay': delay,
        });

        $this.waypoint(function () {
            $this.addClass('animate__animated animate__' + animation);
            $this.css('opacity', 1);
        }, { offset: '90%' });
    });
});
