<?php

// Add a menu item for the FAQ Chatbot
function faq_chatbot_admin_menu() {
    add_menu_page(
        'FAQ Chatbot',
        'FAQ Chatbot',
        'manage_options',
        'faq-chatbot',
        'faq_chatbot_admin_page',
        'dashicons-format-chat'
    );
}
add_action('admin_menu', 'faq_chatbot_admin_menu');

// Admin page content
function faq_chatbot_admin_page() {
    // Save FAQs
    if (!empty($_POST['save_faqs'])) {
        $faqs = isset($_POST['faqs']) ? array_values($_POST['faqs']) : [];
        update_option('faq_chatbot_faqs', $faqs);
        echo '<div class="updated"><p>FAQs saved successfully!</p></div>';
    }

    // Delete a single FAQ
    if (!empty($_POST['delete_faq'])) {
        $faqs = get_option('faq_chatbot_faqs', []);
        $faq_index = intval($_POST['delete_faq']); // Ensure the index is a valid integer
        if (isset($faqs[$faq_index])) {
            unset($faqs[$faq_index]);
            update_option('faq_chatbot_faqs', array_values($faqs)); // Reindex array
            echo '<div class="updated"><p>FAQ deleted successfully!</p></div>';
        }
    }

    // Delete all FAQs
    if (!empty($_POST['delete_all_faqs'])) {
        update_option('faq_chatbot_faqs', []);
        echo '<div class="updated"><p>All FAQs deleted successfully!</p></div>';
    }

    $faqs = get_option('faq_chatbot_faqs', []);
    ?>
    <div class="wrap">
        <h1>FAQ Chatbot</h1>
        <form method="post">
            <table>
                <thead>
                    <tr>
                        <th>Question</th>
                        <th>Answer</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="faq-rows">
                    <?php foreach ($faqs as $index => $faq): ?>
                        <tr>
                            <td><input type="text" name="faqs[<?php echo $index; ?>][question]" value="<?php echo esc_attr($faq['question'] ?? ''); ?>" /></td>
                            <td><textarea name="faqs[<?php echo $index; ?>][answer]"><?php echo esc_textarea($faq['answer'] ?? ''); ?></textarea></td>
                            <td>
                                <button type="submit" name="delete_faq" value="<?php echo $index; ?>">Delete</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <button type="button" id="add-faq-row">Add FAQ</button>
            <input type="submit" name="save_faqs" value="Save FAQs" />
            <?php if (!empty($faqs)): ?>
                <button type="submit" name="delete_all_faqs" value="1" style="background-color: red; color: white;">Delete All</button>
            <?php endif; ?>
        </form>
    </div>
    <script>
        document.getElementById('add-faq-row').addEventListener('click', () => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><input type="text" name="faqs[][question]" /></td>
                <td><textarea name="faqs[][answer]"></textarea></td>
                <td></td>`;
            document.getElementById('faq-rows').appendChild(row);
        });
    </script>
    <?php
}
?>
