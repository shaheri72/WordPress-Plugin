<?php
/**
 * Plugin Name: Interactive FAQ Chatbot
 * Description: A plugin to add an interactive FAQ chatbot to your WordPress site.
 * Version: 1.0
 * Author: Shaher Yar
 */

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin directory constants
define('FAQ_CHATBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));

// Include the admin interface
if (is_admin()) {
    include_once FAQ_CHATBOT_PLUGIN_DIR . 'admin/admin-interface.php';
}

// Enqueue frontend scripts and styles
function faq_chatbot_enqueue_assets() {
    wp_enqueue_style('faq-chatbot-style', plugin_dir_url(__FILE__) . 'public/chatbot.css');
    wp_enqueue_script('faq-chatbot-script', plugin_dir_url(__FILE__) . 'public/chatbot.js', array('jquery'), null, true);

    // Pass AJAX URL to JavaScript
    wp_localize_script('faq-chatbot-script', 'faqChatbotAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
    ));
}
add_action('wp_enqueue_scripts', 'faq_chatbot_enqueue_assets');

// Handle AJAX request
function faq_chatbot_handle_ajax() {
    $question = strtolower(trim($_POST['question'] ?? ''));
    $faqs = get_option('faq_chatbot_faqs', []);

    foreach ($faqs as $faq) {
        if (strpos(strtolower($faq['question']), $question) !== false) {
            wp_send_json_success(['answer' => $faq['answer']]);
        }
    }

    wp_send_json_error(['message' => 'Sorry, I could not find an answer.']);
}
add_action('wp_ajax_faq_chatbot', 'faq_chatbot_handle_ajax');
add_action('wp_ajax_nopriv_faq_chatbot', 'faq_chatbot_handle_ajax');

// Add the chatbot to the site
function faq_chatbot_display() {
    echo '<div id="faq-chatbot">
            <div id="chat-window">
                <div id="chat-log"></div>
                <div id="chat-input">
                    <input type="text" id="chat-question" placeholder="Ask a question..." />
                    <button id="send-question">Send</button>
                </div>
            </div>
          </div>';
}
add_action('wp_footer', 'faq_chatbot_display');
