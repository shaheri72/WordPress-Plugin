jQuery(document).ready(function ($) {
    $('#send-question').on('click', function () {
        const question = $('#chat-question').val();
        if (!question.trim()) return;

        $('#chat-log').append(`<div class="user-message">${question}</div>`);
        $('#chat-question').val('');

        $.post(faqChatbotAjax.ajax_url, { action: 'faq_chatbot', question }, function (response) {
            if (response.success) {
                $('#chat-log').append(`<div class="bot-message">${response.data.answer}</div>`);
            } else {
                $('#chat-log').append(`<div class="bot-message">${response.data.message}</div>`);
            }
        });
    });
});
